-- the script is meant to be used in the Media Explorer

reaper.Main_OnCommand(40632, 0) -- Go to start of loop