-- the script is meant to be used in the Media Explorer

reaper.Main_OnCommand(40042, 0) -- Transport: Go to start of project