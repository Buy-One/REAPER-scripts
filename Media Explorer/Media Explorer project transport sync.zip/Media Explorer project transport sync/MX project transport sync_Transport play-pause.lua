-- the script is meant to be used in the Media Explorer

reaper.Main_OnCommand(40073, 0) -- Transport: Play/pause