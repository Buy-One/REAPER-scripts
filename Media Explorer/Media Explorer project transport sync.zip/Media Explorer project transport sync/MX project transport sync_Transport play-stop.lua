-- the script is meant to be used in the Media Explorer

reaper.Main_OnCommand(40044, 0) -- Transport: Play/stop