-- the script is meant to be used in the Media Explorer

reaper.Main_OnCommand(1007, 0) -- Transport: Play