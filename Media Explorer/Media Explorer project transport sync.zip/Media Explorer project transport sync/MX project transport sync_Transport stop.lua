-- the script is meant to be used in the Media Explorer

reaper.Main_OnCommand(1016, 0) -- Transport: Stop