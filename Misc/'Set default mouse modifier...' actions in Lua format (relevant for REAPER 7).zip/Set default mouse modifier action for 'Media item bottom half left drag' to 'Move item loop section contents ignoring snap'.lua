reaper.SetMouseModifier("Media item bottom half left drag", 0, "Move item loop section contents ignoring snap")

-- MIDI toolbar buttons state isn't updated in sync with Arrange toolbar button state
-- to get a MIDI toolbar button state updated the MIDI toolbar must be closed and re-opened

function Toggle_MIDI_Toolbar_Closed(sect, comm_ID)
	if sect == 32060 then -- search for MIDI toolbar whose button the script is linked to
	local tb = {41687, 41688, 41689, 41690, 41944, 41945, 41946, 41947,
	42745, 42746, 42747, 42748, 42749, 42750, 42751, 42752}
	local tb_No_t = {}
	local path = reaper.GetResourcePath()
	path = path..path:match("[\\/]")
	local found
		for line in io.lines(path.."reaper-menu.ini") do
			if line:match("MIDI toolbar %d+") then found = line		
			elseif found and line:match(comm_ID) then tb_No_t[#tb_No_t+1] = found:match("%d+")
			elseif found and line:match("title") then found = nil
			end
		end		
		if #tb_No_t > 0 then
		-- close MIDI toolbars and return table with their command IDs
		-- to re-open them from the defer loop because due to slowness of toggle state update
		-- immediate triggering of the same action to re-open won't have any effect
			for i = #tb_No_t, 1, -1 do
			local tb_No = tb_No_t[i]
			local tb_comm_ID = tb[tb_No+0]
				if reaper.GetToggleCommandStateEx(0, tb_comm_ID) == 1 then
				reaper.Main_OnCommand(tb_comm_ID, 0) -- close
				tb_No_t[i] = tb_comm_ID -- store toolbar command ID
				else -- if not open, remove from the table
				table.remove(tb_No_t,i)
				end
			end
		return #tb_No_t > 0 and tb_No_t
		end
	end
end

-- defer loop function to monitor MIDI toolbars toggle state
-- to re-open them as soon as their Off state is detected
function Toggle_MIDI_Toolbar_Open()
	if tb_No_t and #tb_No_t > 0 then
		for i = #tb_No_t, 1, -1 do
		local tb_comm_ID = tb_No_t[i]
			if reaper.GetToggleCommandStateEx(0, tb_comm_ID) == 0 then
			reaper.Main_OnCommand(tb_comm_ID, 0) -- re-open
			table.remove(tb_No_t,i) -- if re-opened remove from the table
			end
		end
	reaper.defer(Toggle_MIDI_Toolbar_Open)
	elseif tb_No_t then return
	end
end

local is_new_val, scr_name, sect_ID, cmd_ID, mode, res, val = reaper.get_action_context()
local toggle_state = reaper.GetToggleCommandStateEx(sect_ID, cmd_ID)

	if toggle_state < 1 then
	reaper.SetToggleCommandState(sect_ID, cmd_ID, 1)
	reaper.RefreshToolbar(cmd_ID)	
	local named_cmd_ID = reaper.ReverseNamedCommandLookup(cmd_ID)
	tb_No_t = Toggle_MIDI_Toolbar_Closed(sect_ID, named_cmd_ID)
	local named_cmd_ID2, sect2 = table.unpack(sect_ID == 0 and {named_cmd_ID:gsub("RS", "_RS7d3c_"), 32060}
	or sect_ID == 32060 and {named_cmd_ID:gsub("RS7d3c_", "_RS"), 0} or {})
		if named_cmd_ID2 then 
		-- toggle the same script in another Action list section so its state is synced
		-- in Main and in MIDI Editor sections
		local cmd_ID2 = reaper.NamedCommandLookup(named_cmd_ID2)
		reaper.SetToggleCommandState(sect2, cmd_ID2, 1)
		reaper.RefreshToolbar(cmd_ID2)
		tb_No_t = Toggle_MIDI_Toolbar_Closed(sect2, named_cmd_ID2) or tb_No_t
		end	

	local state = reaper.GetExtState("Media item bottom half left drag", 1)

		if #state > 0 then
		local sect, named_cmd_ID = state:match("(.-):(.+)")
		local cmd_ID = reaper.NamedCommandLookup(named_cmd_ID)
		reaper.SetToggleCommandState(sect, cmd_ID, 0)
		reaper.RefreshToolbar(cmd_ID)
		tb_No_t = Toggle_MIDI_Toolbar_Closed(sect+0, named_cmd_ID) or tb_No_t
		local named_cmd_ID2, sect2 = table.unpack(sect == "0" and {named_cmd_ID:gsub("_RS", "_RS7d3c_"), 32060}
		or sect == "32060" and {named_cmd_ID:gsub("_RS7d3c_", "_RS"), 0} or {})
			if named_cmd_ID2 then
			local cmd_ID2 = reaper.NamedCommandLookup(named_cmd_ID2)
			reaper.SetToggleCommandState(sect2, cmd_ID2, 0)
			reaper.RefreshToolbar(cmd_ID2)
			tb_No_t = Toggle_MIDI_Toolbar_Closed(sect2, named_cmd_ID2) or tb_No_t
			end
		end

	reaper.SetExtState("Media item bottom half left drag", 1, sect_ID..":_"..named_cmd_ID, false) -- persist false
	end


-- Run defer loop to re-open MIDI toolbars after closing in order to refresh their state
-- because it's impossible to toggle it open immediately due to slowness of toggle state update
Toggle_MIDI_Toolbar_Open()




