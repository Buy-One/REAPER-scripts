reaper.SetMouseModifier("Media item left drag", 0, "Marquee select items and time ignoring snap")

local is_new_val, scr_name, sect_ID, cmd_ID, mode, res, val = reaper.get_action_context()
local toggle_state = reaper.GetToggleCommandStateEx(sect_ID, cmd_ID)
local bool = toggle_state < 1 and 1 or 0
reaper.SetToggleCommandState(sect_ID, cmd_ID, bool)
reaper.RefreshToolbar(cmd_ID)
