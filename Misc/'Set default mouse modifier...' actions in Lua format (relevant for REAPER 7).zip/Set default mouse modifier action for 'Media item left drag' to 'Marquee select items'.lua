local context = "Media item left drag"

reaper.SetMouseModifier(context, 0, "Marquee select items")

-- MIDI toolbar buttons state isn't updated in sync with Arrange toolbar button state
-- to get a MIDI toolbar button state updated the MIDI toolbar must be closed and re-opened

function Toggle_MIDI_Toolbars_Closed(context, sect)
	if sect == 32060 then -- search for MIDI toolbar whose button the script is linked to
	local midi_tb = {41687, 41688, 41689, 41690, 41944, 41945, 41946, 41947,
	42745, 42746, 42747, 42748, 42749, 42750, 42751, 42752}
	local path = reaper.GetResourcePath()
	path = path..path:match("[\\/]")
	-- collect command IDs of scripts targeting the same context from the MIDI Editor section
	local sister_scripts_t = {}
		for line in io.lines(path.."reaper-kb.ini") do
			if line:match("32060") and
			-- accounting for context names in which slash was replaced with "or"
			-- to make script file names valid, there'e 5 of those as of REAPER 6.83
			( line:match(context) or line:match(context:gsub("/", " or ")) ) then
			local comm_ID = line:match("32060 (.-) ")
			sister_scripts_t[comm_ID] = ""
			end
		end
	-- collect unique toolbars the scripts collected above are linked to
	local tb_No_t = {}
	local found
		for comm_ID in pairs(sister_scripts_t) do
			for line in io.lines(path.."reaper-menu.ini") do
				if line:match("MIDI toolbar %d+") then found = line
				elseif found and line:match(comm_ID) then
				local tb_No = found:match("%d+")
					if not (function(tb_No) for _, tb in ipairs(tb_No_t) do
							if tb == tb_No then return true end end end)(tb_No)
					then -- wasn't stored yet
					tb_No_t[#tb_No_t+1] = found:match("%d+")
					end
				elseif found and line:match("title") then -- end of section
				found = nil
				end
			end
		end
		if #tb_No_t > 0 then
		-- close MIDI toolbars and return table with their command IDs
		-- to re-open them from the defer loop because due to slowness of toggle state update
		-- immediate triggering of the same action to re-open won't have any effect
			for i = #tb_No_t, 1, -1 do
			local tb_No = tb_No_t[i]
			local tb_comm_ID = midi_tb[tb_No+0]
				if reaper.GetToggleCommandStateEx(0, tb_comm_ID) == 1 then
				reaper.Main_OnCommand(tb_comm_ID, 0) -- close
				tb_No_t[i] = tb_comm_ID -- store toolbar command ID
				else -- if not open, remove from the table
				table.remove(tb_No_t,i)
				end
			end
		return #tb_No_t > 0 and tb_No_t
		end
	end
end

-- defer loop function to monitor MIDI toolbars toggle state
-- to re-open them as soon as their Off state is detected
function Toggle_MIDI_Toolbars_Open()
	if tb_cmd_ID_t and #tb_cmd_ID_t > 0 then
		for i = #tb_cmd_ID_t, 1, -1 do
		local tb_cmd_ID = tb_cmd_ID_t[i]
			if reaper.GetToggleCommandStateEx(0, tb_cmd_ID) == 0 then
			reaper.Main_OnCommand(tb_cmd_ID, 0) -- re-open
			table.remove(tb_cmd_ID_t,i) -- if re-opened remove from the table
			end
		end
	reaper.defer(Toggle_MIDI_Toolbars_Open)
	elseif tb_cmd_ID_t then return
	end
end

local is_new_val, scr_name, sect_ID, cmd_ID, mode, res, val = reaper.get_action_context()
local toggle_state = reaper.GetToggleCommandStateEx(sect_ID, cmd_ID)

-- Set toggle state to On
	if toggle_state < 1 then
	reaper.SetToggleCommandState(sect_ID, cmd_ID, 1)
	reaper.RefreshToolbar(cmd_ID)
	local named_cmd_ID = reaper.ReverseNamedCommandLookup(cmd_ID)
	tb_cmd_ID_t = Toggle_MIDI_Toolbars_Closed(context, sect_ID)
	local named_cmd_ID2, sect2 = table.unpack(sect_ID == 0 and {named_cmd_ID:gsub("RS", "_RS7d3c_"), 32060}
	or sect_ID == 32060 and {named_cmd_ID:gsub("RS7d3c_", "_RS"), 0} or {})
		if named_cmd_ID2 then
		-- toggle the same script in another Action list section so its state is synced
		-- in Main and in MIDI Editor sections
		local cmd_ID2 = reaper.NamedCommandLookup(named_cmd_ID2)
		reaper.SetToggleCommandState(sect2, cmd_ID2, 1)
		reaper.RefreshToolbar(cmd_ID2)
		tb_cmd_ID_t = Toggle_MIDI_Toolbars_Closed(context, sect2) or tb_cmd_ID_t
		end

	local state = reaper.GetExtState(context, "LAST_TOGGLE_ON")

	-- set last On toggle state to Off so that the toggle states of the scripts targeting the same context
	-- are mutually exclusive
		if #state > 0 then
		local sect, named_cmd_ID = state:match("(.-):(.+)")
		local cmd_ID = reaper.NamedCommandLookup(named_cmd_ID)
		reaper.SetToggleCommandState(sect, cmd_ID, 0)
		reaper.RefreshToolbar(cmd_ID)
		tb_cmd_ID_t = Toggle_MIDI_Toolbars_Closed(context, sect+0) or tb_cmd_ID_t
		local named_cmd_ID2, sect2 = table.unpack(sect == "0" and {named_cmd_ID:gsub("_RS", "_RS7d3c_"), 32060}
		or sect == "32060" and {named_cmd_ID:gsub("_RS7d3c_", "_RS"), 0} or {})
			if named_cmd_ID2 then
			local cmd_ID2 = reaper.NamedCommandLookup(named_cmd_ID2)
			reaper.SetToggleCommandState(sect2, cmd_ID2, 0)
			reaper.RefreshToolbar(cmd_ID2)
			tb_cmd_ID_t = Toggle_MIDI_Toolbars_Closed(context, sect2) or tb_cmd_ID_t
			end
		end

	reaper.SetExtState(context, "LAST_TOGGLE_ON", sect_ID..":_"..named_cmd_ID, true) -- persist true

	end


-- Run defer loop to re-open MIDI toolbars after closing inside Toggle_MIDI_Toolbars_Closed() in order to refresh their state
-- because it's impossible to toggle them open immediately due to slowness of toggle state update
Toggle_MIDI_Toolbars_Open()





-- https://forum.cockos.com/showthread.php?t=284185



