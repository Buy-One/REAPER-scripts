reaper.SetMouseModifier("Media item left drag", 0, "Move item vertically ignoring time selection and selection/grouping")

local is_new_val, scr_name, sect_ID, cmd_ID, mode, res, val = reaper.get_action_context()
local toggle_state = reaper.GetToggleCommandStateEx(sect_ID, cmd_ID)

	if toggle_state < 1 then
	reaper.SetToggleCommandState(sect_ID, cmd_ID, 1)	
	local named_cmd_ID = reaper.ReverseNamedCommandLookup(cmd_ID)
	local state = reaper.GetExtState("Media item left drag", 1)

		if #state > 0 then
		local sect, named_cmd_ID = state:match("(.-):(.+)")
		local cmd_ID = reaper.NamedCommandLookup(named_cmd_ID)
		reaper.SetToggleCommandState(sect, cmd_ID, 0)
		reaper.RefreshToolbar(cmd_ID)
		end

	reaper.SetExtState("Media item left drag", 1, cmd_ID..":_"..named_cmd_ID, false) -- persist false
	end

reaper.RefreshToolbar(cmd_ID)





